from django.apps import AppConfig


class CirclelistConfig(AppConfig):
    name = 'circlelist'
