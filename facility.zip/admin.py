from django.contrib import admin
from .models import Facility

# Register your models here.
admin.site.register(Facility)